//
//  main.m
//  ICW02-DiazJ
//
//  Created by Joey Diaz on 9/21/16.
//  Copyright © 2016 Joey Diaz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

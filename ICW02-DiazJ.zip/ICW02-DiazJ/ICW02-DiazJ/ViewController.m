//
//  ViewController.m
//  ICW02-DiazJ
//
//  Created by Joey Diaz on 9/21/16.
//  Copyright © 2016 Joey Diaz. All rights reserved.
//

#import "ViewController.h"





@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *vehicle1Button;
@property (weak, nonatomic) IBOutlet UIButton *vehicle2Button;
@property (weak, nonatomic) IBOutlet UIButton *vehicle3Button;
@property (weak, nonatomic) IBOutlet UISegmentedControl *vehicleTypeButton;
@property (weak, nonatomic) IBOutlet UIImageView *vehicleImageView;
@property (weak, nonatomic) IBOutlet UILabel *makeLabel;
@property (weak, nonatomic) IBOutlet UILabel *modelLabel;
@property (weak, nonatomic) IBOutlet UILabel *mpgLabel;
@property (weak, nonatomic) IBOutlet UILabel *makeInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *modelinfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *mpgInfoLabel;

@property (weak, nonatomic) IBOutlet UIImageView *brandLogoImageView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // vehicle 1 button format
    self.vehicle1Button.layer.cornerRadius = 16.0f;
    self.vehicle1Button.layer.masksToBounds = YES;
    self.vehicle1Button.layer.borderWidth = 2.0f;
    self.vehicle1Button.layer.borderColor = [UIColor blackColor].CGColor;
    
    // vehicle 2 button format
    self.vehicle2Button.layer.cornerRadius = 16.0f;
    self.vehicle2Button.layer.masksToBounds = YES;
    self.vehicle2Button.layer.borderWidth = 2.0f;
    self.vehicle2Button.layer.borderColor = [UIColor blackColor].CGColor;
    
    // vehicle 3 button format
    self.vehicle3Button.layer.cornerRadius = 16.0f;
    self.vehicle3Button.layer.masksToBounds = YES;
    self.vehicle3Button.layer.borderWidth = 2.0f;
    self.vehicle3Button.layer.borderColor = [UIColor blackColor].CGColor;
    self.makeLabel.hidden = YES;
    self.modelLabel.hidden = YES;
    self.mpgLabel.hidden = YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)toggleVehiclesPressed:(UISegmentedControl *)sender {
    if (sender.selectedSegmentIndex == 0) {
        [[self vehicle1Button] setTitle:@"Corolla" forState:UIControlStateNormal];
        [[self vehicle2Button] setTitle:@"Altima" forState:UIControlStateNormal];
        [[self vehicle3Button] setTitle:@"Civic" forState:UIControlStateNormal];
        
        
        
        
    } else {
        [[self vehicle1Button] setTitle:@"F150" forState:UIControlStateNormal];
        [[self vehicle2Button] setTitle:@"Ram 1500" forState:UIControlStateNormal];
        [[self vehicle3Button] setTitle:@"Tacoma" forState:UIControlStateNormal];
    }
}

- (IBAction)button1Pressed:(UIButton *)sender {
    if(self.vehicleTypeButton.selectedSegmentIndex == 0){
        if( [self.vehicle1Button.titleLabel.text isEqual: @"Corolla"]){
            UIImage * picture = [UIImage imageNamed:@"corolla.jpg"];
            [self.vehicleImageView setImage:picture];
            
            self.makeLabel.hidden = NO;
            NSString *makeInfo = @"Toyota";
            self.makeInfoLabel.text = makeInfo;
            self.makeInfoLabel.hidden = NO;
            
            self.modelLabel.hidden = NO;
            NSString *modelInfo = @"Corolla";
            self.modelinfoLabel.text = modelInfo;
            self.modelinfoLabel.hidden = NO;
            
            self.mpgLabel.hidden = NO;
            NSString *mpgInfo = @"28 - 36";
            self.mpgInfoLabel.text = mpgInfo;
            self.mpgInfoLabel.hidden = NO;
            
            self.vehicleImageView.hidden = NO;
            
            UIImage * brandLogo = [UIImage imageNamed:@"toyotaLogo.png"];
            [self.brandLogoImageView setImage:brandLogo];
            self.brandLogoImageView.hidden = NO;
        }
        
    } else if( [self.vehicle1Button.titleLabel.text isEqual: @"F150"]){
        UIImage * picture = [UIImage imageNamed:@"f150.jpg"];
        [self.vehicleImageView setImage:picture];
        
        self.makeLabel.hidden = NO;
        NSString *makeInfo = @"Ford";
        self.makeInfoLabel.text = makeInfo;
        self.makeInfoLabel.hidden = NO;
        
        self.modelLabel.hidden = NO;
        NSString *modelInfo = @"F150";
        self.modelinfoLabel.text = modelInfo;
        self.modelinfoLabel.hidden = NO;
        
        self.mpgLabel.hidden = NO;
        NSString *mpgInfo = @"19 - 26";
        self.mpgInfoLabel.text = mpgInfo;
        self.mpgInfoLabel.hidden = NO;
        
        self.vehicleImageView.hidden = NO;
        
        UIImage * brandLogo = [UIImage imageNamed:@"fordLogo.jpg"];
        [self.brandLogoImageView setImage:brandLogo];
        self.brandLogoImageView.hidden = NO;

        
    }
}

- (IBAction)vehicle2ButtonPressed:(UIButton *)sender {
    if(self.vehicleTypeButton.selectedSegmentIndex == 0){
        if( [self.vehicle2Button.titleLabel.text isEqual: @"Altima"]){
            UIImage * picture = [UIImage imageNamed:@"altima.jpg"];
            [self.vehicleImageView setImage:picture];
            
            self.makeLabel.hidden = NO;
            NSString *makeInfo = @"Nissan";
            self.makeInfoLabel.text = makeInfo;
            self.makeInfoLabel.hidden = NO;
            
            self.modelLabel.hidden = NO;
            NSString *modelInfo = @"Altima";
            self.modelinfoLabel.text = modelInfo;
            self.modelinfoLabel.hidden = NO;
            
            self.mpgLabel.hidden = NO;
            NSString *mpgInfo = @"27 - 39";
            self.mpgInfoLabel.text = mpgInfo;
            self.mpgInfoLabel.hidden = NO;
            
            self.vehicleImageView.hidden = NO;
            
            UIImage * brandLogo = [UIImage imageNamed:@"nissanLogo.jpg"];
            [self.brandLogoImageView setImage:brandLogo];
            self.brandLogoImageView.hidden = NO;
        }
        
    } else if( [self.vehicle2Button.titleLabel.text isEqual: @"Ram 1500"]){
        UIImage * picture = [UIImage imageNamed:@"ram1500.jpg"];
        [self.vehicleImageView setImage:picture];
        
        self.makeLabel.hidden = NO;
        NSString *makeInfo = @"Dodge";
        self.makeInfoLabel.text = makeInfo;
        self.makeInfoLabel.hidden = NO;
        
        self.modelLabel.hidden = NO;
        NSString *modelInfo = @"Ram 1500";
        self.modelinfoLabel.text = modelInfo;
        self.modelinfoLabel.hidden = NO;
        
        self.mpgLabel.hidden = NO;
        NSString *mpgInfo = @"21 - 29";
        self.mpgInfoLabel.text = mpgInfo;
        self.mpgInfoLabel.hidden = NO;
        
        self.vehicleImageView.hidden = NO;
        
        UIImage * brandLogo = [UIImage imageNamed:@"dodgeLogo.png"];
        [self.brandLogoImageView setImage:brandLogo];
        self.brandLogoImageView.hidden = NO;
    }

}

- (IBAction)vehicle3ButtonPressed:(UIButton *)sender {
    if(self.vehicleTypeButton.selectedSegmentIndex == 0){
        if( [self.vehicle3Button.titleLabel.text isEqual: @"Civic"]){
            UIImage * picture = [UIImage imageNamed:@"civic.jpg"];
            [self.vehicleImageView setImage:picture];
            
            self.makeLabel.hidden = NO;
            NSString *makeInfo = @"Honda";
            self.makeInfoLabel.text = makeInfo;
            self.makeInfoLabel.hidden = NO;
            
            self.modelLabel.hidden = NO;
            NSString *modelInfo = @"Civic";
            self.modelinfoLabel.text = modelInfo;
            self.modelinfoLabel.hidden = NO;
            
            self.mpgLabel.hidden = NO;
            NSString *mpgInfo = @"31 - 42";
            self.mpgInfoLabel.text = mpgInfo;
            self.mpgInfoLabel.hidden = NO;
            
            self.vehicleImageView.hidden = NO;
            
            UIImage * brandLogo = [UIImage imageNamed:@"hondaLogo.png"];
            [self.brandLogoImageView setImage:brandLogo];
            self.brandLogoImageView.hidden = NO;
        }
        
    } else if( [self.vehicle3Button.titleLabel.text isEqual: @"Tacoma"]){
        UIImage * picture = [UIImage imageNamed:@"tacoma.jpg"];
        [self.vehicleImageView setImage:picture];
        
        self.makeLabel.hidden = NO;
        NSString *makeInfo = @"Toyota";
        self.makeInfoLabel.text = makeInfo;
        self.makeInfoLabel.hidden = NO;
        
        self.modelLabel.hidden = NO;
        NSString *modelInfo = @"Tacoma";
        self.modelinfoLabel.text = modelInfo;
        self.modelinfoLabel.hidden = NO;
        
        self.mpgLabel.hidden = NO;
        NSString *mpgInfo = @"19 - 24";
        self.mpgInfoLabel.text = mpgInfo;
        self.mpgInfoLabel.hidden = NO;
        
        self.vehicleImageView.hidden = NO;
        
        UIImage * brandLogo = [UIImage imageNamed:@"toyotaLogo.png"];
        [self.brandLogoImageView setImage:brandLogo];
        self.brandLogoImageView.hidden = NO;
    }

}

-(IBAction)hideWhenVehicleChanged:(id)sender{
    self.makeLabel.hidden = YES;
    self.mpgLabel.hidden = YES;
    self.modelLabel.hidden = YES;
    self.mpgLabel.hidden = YES;
    self.makeInfoLabel.hidden = YES;
    self.modelinfoLabel.hidden = YES;
    self.mpgInfoLabel.hidden = YES;
    self.vehicleImageView.hidden = YES;
    self.brandLogoImageView.hidden = YES;
}

@end

//
//  main.m
//  Q1-DiazJ
//
//  Created by Joey Diaz on 9/5/16.
//  Copyright © 2016 joeydiaz.com. All rights reserved.
//

#import <Foundation/Foundation.h>

// clean up and remove the date and format of NSLog
#define NSLog(FORMAT, ...) printf("%s\n", [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);

int main(int argc, const char * argv[])
{//begin main
    
    @autoreleasepool
    {
        // boolean variable to be used by the principal do while loop
        BOOL guessedNumber = false;
        
        // accumulator variable keeps track of attempts
        unsigned int numOfTries = 0;
        
        do
     
        {//begin doWhile
            
            // create a random number from 1-100
            unsigned int randomNumber = arc4random_uniform(101);
            
            // declare an array to hold 20 characters
            char userInput[20];
            
            // accumulator variable to count and limit the attempts
            unsigned int counter = 0;
            
            // * not part of requirements *
            // limiting wrong input(character or negative)to up to five attempts
            unsigned int wrongInput = 0;
            
            //used for testing purposes to SEE THE NUMBER CREATED HERE
            NSLog(@"My number is %i", randomNumber);//@"
            
            // message to user
            NSLog(@"Hi! My name is Randy.");
            NSLog(@"I am a robot that generates random numbers.");
            NSLog(@"Let's play a game. I think of a number and you try to guess it.");
            NSLog(@"Too difficult? OK, let me make it easier for you.");
            NSLog(@"The number must be between 0 and 100 inclusive.");
            NSLog(@"Hold on a sec, let me think of a number.");
            NSLog(@"");
            NSLog(@"Ok, I already have my number in mind.");
            NSLog(@"Your turn to guess it.");
            
            // limiting attempts to 10
            while(counter < 10)
          
            {//beginWHILE
                
                // message to user prompting to enter the guess number
                NSLog(@"Enter your guess number now: ");
                
                // read it from user input
                scanf("%s", userInput);
                
                // declare an NSString and feed it with the array of characters read in
                NSString *inputToCString = [NSString stringWithCString:userInput encoding:1];
                
                // convert a CString to integer
                NSInteger CStringToInteger = [inputToCString integerValue];
                
                // input validation of negative numbers
                if( ((int)CStringToInteger) < 0 )
             
                {//beingIF
                    
                    // message to user
                    NSLog(@"\nNegative numbers NOT allowed.");
                    
                    // increment
                    wrongInput++;
                    
                    // condition to limit wrong inputs
                    if(wrongInput > 5)
                 
                    {//beginIF
                        
                        // message to user
                        NSLog(@"Program terminates due to exceeded wrong inputs.");
                        
                        // exit by force
                        exit(0);
                        
                    }//endIF
                    
                }//end IF
                
                // input validation of characters
                else if( (int)CStringToInteger == 0 )
            
                {//beginELSEIF
                    
                    // message to user
                    NSLog(@"\nCharacters NOT allowed.");
                    
                    // increment
                    wrongInput++;
                    
                    // condition to limit wrong inputs
                    if(wrongInput > 5)
                   
                    {//beginIF
                        
                        // message to user
                        NSLog(@"Program terminates due to exceeded wrong inputs.");
                        
                        // exit by force
                        exit(0);
                        
                    }//endIF
                    
                }//endELSEIF
                
                // input validation to compare input to random number
                // input is less tha randonm number created
                else if( (int)CStringToInteger < randomNumber )
               
                {//beginELSEIF
                    
                    // message to user
                    NSLog(@"\nSorry, that's too low.");
                    
                    // increment
                    numOfTries++;
                    
                    // increment
                    counter++;
                    
                }//endELSEIF
                
                // input validation to compare input to random number
                // input is greater than random number created
                else if( (int)CStringToInteger > randomNumber )
               
                {//beginELSEIF
                    
                    // message to user
                    NSLog(@"\nSorry, that's too high.");
                    
                    // increment
                    numOfTries++;
                    
                    // increment
                    counter++;
                    
                }//endELSEIF
                
                // input validation to compare input to random number
                // input is equal to random number created
                else if( (int)CStringToInteger == randomNumber )
               
                {//beginELSEIF
                    
                    // increment
                    numOfTries++;
                    
                    // condition in case user guessed it at first attempt
                    if(numOfTries == 1)
                   
                    {//beginIF
                        
                        // customized message to user
                        NSLog(@"\n****************");
                        NSLog(@"Congratulations!");
                        NSLog(@"****************");
                        NSLog(@"It took you only %i try to guess my number.\n", numOfTries);
                        
                        // reset accumulator
                        numOfTries = 0;
                        
                        // exit loop
                        break;
                        
                    }//endIF
                    
                    // condition in case user guessed it in 2 or more attempts
                    else
                 
                    {//beginELSE
                        
                        // customize message to user
                        NSLog(@"\n****************");
                        NSLog(@"Congratulations!");
                        NSLog(@"****************");
                        NSLog(@"It took you %i tries to guess my number.\n", numOfTries);
                        
                        // reset accumulator
                        numOfTries = 0;
                        
                        // exit loop
                        break;
                        
                    }//endELSE
                    
                }//endELSEIF
                
            }//end while
            
            // condition to limit attempts to 10
            if(counter >=10)
          
            {//beginIF
                
                // mesage to user
                NSLog(@"You could not guess my number in %i tries.\n", numOfTries);
                
            }//endIF
            
            // condition in the event the number is not guessed
            while(guessedNumber == false)
         
            {//beingWHILE
                
                // message to user
                NSLog(@"Would you like to play again?");
                NSLog(@"Enter < 1 > to PLAY AGAIN");
                NSLog(@"OR");
                NSLog(@"Enter < 2 > to EXIT");
                NSLog(@"Your selection is: ");
                
                // read it from user input
                scanf("%s", userInput);
                
                // declare an NSString and feed it with the array of characters read in
                NSString *inputToCString = [NSString stringWithCString:userInput encoding:1];
                
                // convert a CString to integer
                NSInteger CStringToInteger = [inputToCString integerValue];
                
                // in the event the user wants to continue playing
                if( (int)CStringToInteger == 1 )
               
                {//beginIF
                    
                    // message to user
                    NSLog(@"\n< LET'S PLAY AGAIN >");
                    
                    // exit loop
                    break;
                    
                }//endIF
                
                // in the event the user wants to quit
                else if( (int)CStringToInteger == 2 )
                
                {//beginELSEIF
                    
                    // message to user
                    NSLog(@"\n< EXIT >");
                    NSLog(@"It was nice playing with you.");
                    
                    // exit the principal loop and terminate
                    guessedNumber = true;
                    
                }//endELSEIF
                
                // input validation for negative numbers
                else if( ((int)CStringToInteger) < 0 )
                
                {//beginELSEIF
                    
                    //message to user
                    NSLog(@"\nNegative numbers NOT allowed.");
                    
                    // increment
                    wrongInput++;
                    
                    // limit wrong inputs
                    if(wrongInput > 5)
                  
                    {//beginIF
                        
                        // message to user
                        NSLog(@"Program terminates due to exceeded wrong inputs.");
                        
                        // exit by force
                        exit(0);
                        
                    }//endIF
                    
                }//endELSEIF
                
                // input validation for characters
                else if( (int)CStringToInteger == 0 )
                
                {//beginELSEIF
                    
                    // message to user
                    NSLog(@"\nCharacters NOT allowed.");
                    
                    // increment
                    wrongInput++;
                    
                    // condition to limit wrong input to 5
                    if(wrongInput > 5)
                    
                    {//beginIF
                        
                        // message to user
                        NSLog(@"Program terminates due to exceeded wrong inputs.");
                        
                        // exit by force
                        exit(0);
                        
                    }//endIF
                    
                }//endELSEIF
                
            }//endWHILE
            
        }while(guessedNumber == false);//end doWhile
        
    }
    
    return 0;
    
}//end main

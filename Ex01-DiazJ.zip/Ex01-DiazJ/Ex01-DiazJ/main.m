//
//  main.m
//  Ex01-DiazJ
//
//  Created by Joey Diaz on 8/29/16.
//  Copyright © 2016 joeydiaz.com. All rights reserved.
//

#import <Foundation/Foundation.h>

// code to eliminate the log and date at print time
#define NSLog(FORMAT, ...) printf("%s\n", [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);

const float NO_DISCOUNT_TICKET_COST = 10.00; // price per ticket if user buys 4 or less tickets
const float DISCOUNTED_TICKET_COST = 8.00; // price per ticket if user buys 5 or more tickets
const float REGAL_MEMBER_DISCOUNT = 0.05; // discount applied to Regal Members

int main(int argc, const char * argv[]) {
    @autoreleasepool
    {
        unsigned int counter = 0; // counter used for the while loops
        unsigned int languageSelection = 0; // language selection variable
        unsigned int mainMenuOption = 0; // main menu variable
        
        // main messge
        NSLog(@"+-------------------------------------------------------+\n"
              "| R E G A L    E N T E R T A I N T M E N T    G R O U P |\n"
              "+-------------------------------------------------------+\n"
              "|      Welcome to the best movie theater in Miami       |\n"
              "+-------------------------------------------------------+");
        
        while (counter <= 5) // while loop limiting the mistaken input to 5 attempts
        { // beginWHILE
            
            // language selector message
            NSLog(@"|\tPlease select one of the languages below:\n"
                  "|\t< 1 > For ENGLISH\n"
                  "|\t< 2 > Para ESPANOL\n"
                  "|\tEnter your language selection now:");
            NSLog(@"\t"); // format purpose
            
            char userInput[20]; // declare a variable to hold 40 characters
            
            scanf("%s", userInput); // read it from user input
            
            NSString *result; // declare an NSString
            
            // initialize the NSString with the list of characters read in
            result = [NSString stringWithCString:userInput encoding:1];
            
            NSInteger inputToInteger = [result integerValue]; // describe the integer that represents the input
            
            if( ((int)inputToInteger) == 1) // convert and compare the input to an int
            { // beginIF
                languageSelection = 1; // enter the switch
                break; // exit loop
            } //endIF
            
            else if( ((int)inputToInteger) == 2) // convert and cmompare the input to an int
            { // beginELSEif
                languageSelection = 2; // enter the switch
                break; // exit loop
            } // endELSEif
            
            else // validating input for only 1 or 2
            { // beginELSE
                
                NSLog(@"Invalid option"); // message to user
                counter++; // increment counter
                if (counter > 5) //after reaching 5 attempts defaults to English
                { // beginIF
                    
                    languageSelection = 1; // entering the swith as English
                    NSLog(@"Language defaulted to English"); // message to user
                    
                } //endIF
                
            } // endELSE
        }// end while
        
        switch (languageSelection)
        { // begin switch
                
            case 1: // case 1 is for English
            { // beginCASE1
                
                counter = 0; // reset the counter variable
                while (counter <=5) // limit the attempts to 5
                { // beginWHILE
                    
                    // main menu message to user
                    NSLog(@"+--------------------------------------------------------\n"
                          "|\tENGLISH - MAIN MENU\n"
                          "+--------------------------------------------------------\n"
                          "|\tPlease, choose one option below:\n"
                          "|\t< 1 > Purchase Tickets\n"
                          "|\t< 2 > Quit the program\n"
                          "|\tEnter your selection:");
                    NSLog(@"\t"); // format purposes
                    
                    char userInput[20]; // declare a variable to hold 20 characters
                    
                    scanf("%s", userInput); // read it from user input
                    
                    NSString *result; // declare an NSString
                    
                    // initialize the NSString with the list of characters read in
                    result = [NSString stringWithCString:userInput encoding:1];
                    
                    NSInteger inputToInteger = [result integerValue]; // convert to integer
                    
                    if( ((int)inputToInteger) == 1) // if the customer wants to buy tickets
                    { // beginIF
                        mainMenuOption = 1; // set variable to 1
                        
                        // question to the user requiring input
                        NSLog(@"+--------------------------------------------------------\n"
                              "|\tHow many tickets would you like to purchase today?\n"
                              "+--------------------------------------------------------");
                        unsigned int numOfTicketsPurchased = 0; // initialize variable to hold tickets bought
                        scanf("%d", &numOfTicketsPurchased); // read value from user
                        
                        // question to the user requiring input
                        NSLog(@"\n+--------------------------------------------------------\n"
                              "|\tAre you a member of the Regal Crown Club?\n"
                              "+--------------------------------------------------------\n"
                              "Enter (y/n): "); // input from user required
                       
                        char yesORno[4]; // limit input to 4 characters
                        
                        scanf("%s", yesORno); // read value from user
                        
                        float total = 0; // initialize variable to hold total cost
                        
                        if(numOfTicketsPurchased <= 4) // price varies depending on number of tickets bought
                        { // beginIF
                            
                            // calculation of price
                            total = (NO_DISCOUNT_TICKET_COST * numOfTicketsPurchased);
                            
                            // input validation for upper/lower case (not required per specs)
                            if(yesORno[0] == 'y' || yesORno[0] == 'Y')
                            { // beginIF
                                
                                total -= (total * REGAL_MEMBER_DISCOUNT); // calculate total after discount
                                
                                // message to user informing about total, savings and price earned
                                NSLog(@"\n+---------------------------------------");
                                NSLog(@"|\tYour total is $%.2f", total);
                                NSLog(@"+---------------------------------------");
                                NSLog(@"|\tAs a priviledged Regal Member you:");
                                NSLog(@"|\tSaved:  $%.2f",(numOfTicketsPurchased *
                                                           NO_DISCOUNT_TICKET_COST)-total);
                                NSLog(@"|\tEarned: (1)Free Small Popcorn");
                                NSLog(@"+---------------------------------------\n"
                                      "|\tThank you for your business!\n"
                                      "+---------------------------------------");
                            } // endIF
                            
                            // input validation for upper/lower case (not required per specs)
                            else if(yesORno[0] == 'n' || yesORno[0] == 'N')
                            { // beginELSEif
                                
                                // calculate total after no discount
                                total = (NO_DISCOUNT_TICKET_COST * numOfTicketsPurchased);
                                
                                // message to user informing about total and thanking him/her
                                NSLog(@"\n+---------------------------------------\n"
                                      "|\tYour total is $%.2f", total);
                                NSLog(@"+---------------------------------------");
                                NSLog(@"|\tThank you for your business!\n"
                                      "+---------------------------------------");
                            } // endELSEif
                            
                        } // endIF
                        
                        else if(numOfTicketsPurchased >=5) // ticket price changes depending on qty bought
                        { // beginELSEif
                            
                            // calculating total after discounts
                            total = (DISCOUNTED_TICKET_COST * numOfTicketsPurchased);
                            
                            // input validation for upper/lower case (not required per specs)
                            if(yesORno[0] == 'y' || yesORno[0] == 'Y')
                            { // beginIF
                                
                                total -= (total * REGAL_MEMBER_DISCOUNT);
                                NSLog(@"\n+---------------------------------------\n"
                                      "|\tYour total is $%.2f", total);
                                NSLog(@"+---------------------------------------");
                                NSLog(@"|\tAs a priviledged Regal Member you:");
                                NSLog(@"|\tSaved:  $%.2f",(numOfTicketsPurchased *
                                                           DISCOUNTED_TICKET_COST)-total);
                                NSLog(@"|\tEarned: (1)Free Small Popcorn\n"
                                      "+---------------------------------------\n"
                                      "|\tThank you for your business!\n"
                                      "+---------------------------------------");
                            } // endIF
                            
                            // input validation for upper/lower case (not required per specs)
                            else if(yesORno[0] == 'n' || yesORno[0] == 'N')
                            { // beginELSEif
                                
                                // calculate total
                                total = (DISCOUNTED_TICKET_COST * numOfTicketsPurchased);
                                
                                // message to user informing about total and thanking him/her
                                NSLog(@"\n+---------------------------------------");
                                NSLog(@"|\tYour total is $%.2f", total);
                                NSLog(@"+---------------------------------------");
                                NSLog(@"|\tThank you for your business!");
                                NSLog(@"+---------------------------------------");
                            } // endELSEif
                            
                        } // endELSEif
                        
                        break; //exit loop
                        
                    }// endIF
                   
                    else if( ((int)inputToInteger) == 2) // option 2 is to terminate program
                    { // beginELSEif
                        
                        // message to user informing about program intentional abortion
                        NSLog(@"Program terminated by the user");
                        break; // exit loop
                    } // endELSEif
                    
                    else
                    { // beginELSE
                        
                        NSLog(@"Invalid option"); // message to user informing about wrong option selected
                        counter++; // increment counter
                       
                        if (counter > 5)
                        { // beginIF
                            
                            // message to user informing about program termination
                            NSLog(@"All attempts used.\n"
                                  "Program terminates now.");
                        } // endIF
                    } // endELSE
                } // endWHILE
            } // endCASE1
                break; // exit loop
                
  // NOTE: THE STRUCTURE, LOGIC AND ORDER OF THE SPANISH SECTION IS IDENTICAL TO THE ONE IN ENGLISH.
  // THEREFORE, COMMENTS ON THE SPANISH SECTION HAVE NOT BEEN INCLUDED.
                
            case 2:
            {
                NSLog(@"+--------------------------------------------------------\n"
                      "|\tESPANOL - MENU PRINCIPAL\n"
                      "+--------------------------------------------------------\n"
                      "|\tPor favor, escoja una de las opciones:\n"
                      "|\t< 1 > Comprar Entradas\n"
                      "|\t< 2 > Salir del programa");
                NSLog(@"\t");
                
                char userInput[20];
                
                scanf("%s", userInput);
                
                NSString *result;
                
                result = [NSString stringWithCString:userInput encoding:1];
                
                NSInteger inputToInteger = [result integerValue];
                
                if( ((int)inputToInteger) == 1)
                {
                    mainMenuOption = 1;
                    NSLog(@"+--------------------------------------------------------\n"
                          "|\tCuantas entradas quisiera compar hoy?\n"
                          "+--------------------------------------------------------");
                    unsigned int numOfTicketsPurchased = 0;
                    scanf("%d", &numOfTicketsPurchased);
                    NSLog(@"\n+--------------------------------------------------------\n"
                          "|\tEs usted miembro del Club Regal Crown?\n"
                          "+--------------------------------------------------------\n"
                          "Entre (s/n): ");
                    char yesORno[4];
                    scanf("%s", yesORno);
                    
                    float total = 0;
                    if(numOfTicketsPurchased <= 4)
                    {
                        total = (NO_DISCOUNT_TICKET_COST * numOfTicketsPurchased);
                        if(yesORno[0] == 's' || yesORno[0] == 'S')
                        {
                            total -= (total * REGAL_MEMBER_DISCOUNT);
                            NSLog(@"\n+--------------------------------------------------------");
                            NSLog(@"|\tSu total es $%.2f", total);
                            NSLog(@"+--------------------------------------------------------");
                            NSLog(@"|\tComo miembro privilegiado del Club Regal usted:");
                            NSLog(@"|\tAhorro:  $%.2f",(numOfTicketsPurchased *
                                                        NO_DISCOUNT_TICKET_COST)-total);
                            NSLog(@"|\tGano:    (1)Bolsa Pequena de Palomitas");
                            NSLog(@"+--------------------------------------------------------\n"
                                  "|\tGracias por hacer negocios con nosotros!\n"
                                  "+--------------------------------------------------------");
                            
                        }
                       
                        else if(yesORno[0] == 'n' || yesORno[0] == 'N')
                        {
                            total = (NO_DISCOUNT_TICKET_COST * numOfTicketsPurchased);
                            NSLog(@"\n+--------------------------------------------------------\n"
                                  "|\tSu total es $%.2f", total);
                            NSLog(@"+--------------------------------------------------------");
                            NSLog(@"|\tGracias por hacer negocios con nosotros!\n"
                                  "+--------------------------------------------------------");
                        }
                    }
                    
                    else if(numOfTicketsPurchased >=5)
                    {
                        total = (DISCOUNTED_TICKET_COST * numOfTicketsPurchased);
                        if(yesORno[0] == 's' || yesORno[0] == 'S')
                        {
                            total -= (total * REGAL_MEMBER_DISCOUNT);
                            NSLog(@"\n+--------------------------------------------------------\n"
                                  "|\tSu total es $%.2f", total);
                            NSLog(@"+--------------------------------------------------------");
                            NSLog(@"|\tComo miembro privilegiado del Club Regal usted:");
                            NSLog(@"|\tAhorro:  $%.2f",(numOfTicketsPurchased *
                                                        DISCOUNTED_TICKET_COST)-total);
                            NSLog(@"|\tGano:    (1)Bolsa Pequena de Palomitas\n"
                                  "+--------------------------------------------------------\n"
                                  "|\tGracias por hacer negocios con nosotros!\n"
                                  "+--------------------------------------------------------");
                        }
                        
                        else if(yesORno[0] == 'n' || yesORno[0] == 'N')
                        {
                            total = (DISCOUNTED_TICKET_COST * numOfTicketsPurchased);
                            NSLog(@"\n+--------------------------------------------------------");
                            NSLog(@"|\tSu total es $%.2f", total);
                            NSLog(@"+--------------------------------------------------------");
                            NSLog(@"|\tGracias por hacer negocios con nosotros!");
                            NSLog(@"+--------------------------------------------------------");
                        }
                    }
                    break;
                }
               
                else if( ((int)inputToInteger) == 2)
                {
                    NSLog(@"El usuario termino el programa");
                    break;
                }
                
                else
                {
                    NSLog(@"Opcion invalida");
                    counter++;
                    if (counter > 5)
                    {
                        NSLog(@"Se han usado todos los intentos.\n"
                              "El programa termina ahora.");
                    }
                }
            }
                break;
        }
        return 0;
    }
}
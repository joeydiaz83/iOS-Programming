//
//  ViewController.h
//  Ex.02.-DiazJ
//
//  Created by Joey Diaz on 9/24/16.
//  Copyright © 2016 Joey Diaz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


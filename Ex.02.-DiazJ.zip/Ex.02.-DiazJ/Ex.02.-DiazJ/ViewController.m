//
//  ViewController.m
//  Ex.02.-DiazJ
//
//  Created by Joey Diaz on 9/24/16.
//  Copyright © 2016 Joey Diaz. All rights reserved.
//

const double SPEED_CONVERSION_VALUE = 0.62137;
const double POUNDS_CONVERSION_VALUE = 2.2046226218488;
const double GALLONS_TO_LITERS_VALUE = 3.785411784;
const double LITERS_TO_GALLONS_VALUE = 0.26417205235815;
#import "ViewController.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UISegmentedControl *unitTypeButton;
@property (weak, nonatomic) IBOutlet UITextField *topTextField;
@property (weak, nonatomic) IBOutlet UITextField *bottomTextField;
@property (weak, nonatomic) IBOutlet UIImageView *metricIconImageView;
@property (weak, nonatomic) IBOutlet UILabel *unitMeasureTopLabel;
@property (weak, nonatomic) IBOutlet UILabel *unitMeasureBottomLabel;
@property (weak, nonatomic) IBOutlet UILabel *metricLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // set the initial load to be Temperature and its characteristics
    UIImage *metricPic = [UIImage imageNamed:@"temperatureMonoFinal.png"];
    [self.metricIconImageView setImage:metricPic];
    [self.titleLabel setText:@"Converter Master"];
    [self.metricLabel setText:@"Temperature"];
    [self.unitMeasureTopLabel setText:@"°C"];
    [self.unitMeasureBottomLabel setText:@"°F"];
    [self.topTextField setPlaceholder:@"Degree Celsius"];
    [self.bottomTextField setPlaceholder:@"Degree Farenheit"];    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// if top text field is first responder
- (IBAction)inputingTopField:(id)sender {
    

    // if Temperature selected
    if(self.unitTypeButton.selectedSegmentIndex == 0){
        
        // clear at begining of typing
        self.topTextField.clearsOnBeginEditing = YES;
        
        
        // retrieve value from the textfield
        double celsiusInput = [self.topTextField.text doubleValue];
        
        
        // Celsius to Farenheit
        // Celsius * 1.8 + 32 = Farenheit
        // compute
        double celsiusToFarenheit =
        celsiusInput * 1.8 + 32;
        
        // convert the result to a string to display it
        NSString *celToFarConversion =
        [NSString stringWithFormat:@"%.4f",celsiusToFarenheit];
        
        // set the bottom textfield with the conversion value
        [self.bottomTextField setText:celToFarConversion];
        
        // if Speed is selected
    } else if (self.unitTypeButton.selectedSegmentIndex == 1) {
        
        // clear at begining of typing
        self.topTextField.clearsOnBeginEditing = YES;
        
        // retrieve value from the textfield
        double milesInput = [self.topTextField.text doubleValue];
        
        // Miles to Kilometers
        // Miles / 0.62137
        // compute
        double milesToKilometers = milesInput / SPEED_CONVERSION_VALUE;
        
        // convert the result to a string to display it
        NSString *milToKilConversion = [NSString stringWithFormat:@"%.4f",milesToKilometers];
        
        // set the bottom textfield with the conversion value
        [self.bottomTextField setText:milToKilConversion];
        
        
       
        
        
        
        // if Weight is selected
    } else if(self.unitTypeButton.selectedSegmentIndex == 2){
        
        // clear at begining of typing
        self.topTextField.clearsOnBeginEditing = YES;
        
        // retrieve value from the textfield
        double poundsInput = [self.topTextField.text doubleValue];
        
        // Pounds to Kilograms
        // Pounds / 2.2046226218488
        // compute
        double poundsToKilograms = poundsInput / POUNDS_CONVERSION_VALUE;
        
        // convert the result to a string to display it
        NSString *poundsToKilosConversion = [NSString stringWithFormat:@"%.4f", poundsToKilograms];
        
        // set the bottom textfield with the conversion value
        [self.bottomTextField setText:poundsToKilosConversion];
        
        // if Fluid is selected
    } else if(self.unitTypeButton.selectedSegmentIndex == 3){
        
        // clear at begining of typing
        self.topTextField.clearsOnBeginEditing = YES;
        
        // retrieve value from the textfield
        double gallonsInput = [self.topTextField.text doubleValue];
        
        // Gallons to liters
        // Liters = gallons * 3.785411784
        // compute
        double gallonsToLiters =
        gallonsInput * GALLONS_TO_LITERS_VALUE;
        
        // convert the result to a string to display it
        NSString *gallToLitersConversion = [NSString stringWithFormat:@"%.4f", gallonsToLiters];
        
        // set the bottom textfield with the conversion value
        [self.bottomTextField setText:gallToLitersConversion];
    }
}

// if bottom text field is first responder
- (IBAction)inputingBottomField:(id)sender {
    

    // if Temperature is selected
    if(self.unitTypeButton.selectedSegmentIndex == 0){
        
        // clear at begining of typing
        self.bottomTextField.clearsOnBeginEditing = YES;
        
        // retrieve value from the textfield
        double farenheitInput = [self.bottomTextField.text doubleValue];
        
        // Farenheit to Celsius
        // (Farenheit - 32) * 0.5556 = Celsius
        // compute
        double farenheitToCelsius =
        (farenheitInput - 32) * 5.0/9;
        
        // convert the result to a string to display it
        NSString *farToCelConversion = [NSString stringWithFormat:@"%.4f", farenheitToCelsius];
        
        // set top text field with the conversion value
        [self.topTextField setText:farToCelConversion];
        

        
        // if Speed is selected
    }else if(self.unitTypeButton.selectedSegmentIndex == 1){
        
        // clear at begining of typing
        self.bottomTextField.clearsOnBeginEditing = YES;
        
        // retrieve value from the textfield
        double kilometersinput = [self.bottomTextField.text doubleValue];
        
        // kilometers to miles
        // miles = kilometers * 0.62137
        // compute
        double kilometersToMiles =
        kilometersinput * SPEED_CONVERSION_VALUE;
        
        // convert the result to a string to display it
        NSString *kilToMilConversion = [NSString stringWithFormat:@"%.4f", kilometersToMiles];
        
        // set top text field with the conversion value
        [self.topTextField setText:kilToMilConversion];
        
        // if Weight is selected
    } else if(self.unitTypeButton.selectedSegmentIndex == 2){
        
        // clear at begining of typing
        self.bottomTextField.clearsOnBeginEditing = YES;
        
        // retrieve value from the textfield
        double kilogramsInput = [self.bottomTextField.text doubleValue];
        
        // kilograms to pounds
        // pounds = kilograms * 2.2046226218488
        // compute
        double kilogramsToPounds =
        kilogramsInput * POUNDS_CONVERSION_VALUE;
        
        // convert the result to a string to display it
        NSString *kilogramsToPoundsConversion = [NSString stringWithFormat:@"%.4f",kilogramsToPounds];
        
        // set top text field with the conversion value
        [self.topTextField setText:kilogramsToPoundsConversion];
        
        // if Fluid is selected
    } else if(self.unitTypeButton.selectedSegmentIndex == 3){
        
        // clear at begining of typing
        self.bottomTextField.clearsOnBeginEditing = YES;
        
        double litersInput = [self.bottomTextField.text doubleValue];
        // liters to gallons
        // gallons = liters * 0.26417205235815
        // compute
        double litersToGallons =
        litersInput * LITERS_TO_GALLONS_VALUE;
        
        // convert the result to a string to display it
        NSString *litersToGallonConversion = [NSString stringWithFormat:@"%.4f", litersToGallons];
        
        // set top text field with the conversion value
        [self.topTextField setText:litersToGallonConversion];
    }
}

// set up the screen based on the segmented control value
- (IBAction)metricChosen:(UISegmentedControl *)sender {
    
    // if Temperature is selected
    if(self.unitTypeButton.selectedSegmentIndex == 0){
        
        // display images and labels related to temperature
        [self.unitMeasureTopLabel setText:@"°C"];
        [self.unitMeasureBottomLabel setText:@"°F"];
        [self.metricLabel setText:@"Temperature"];
        [self.topTextField setPlaceholder:@"Degree Celsius"];
        [self.bottomTextField setPlaceholder:@"Degree Farenheit"];
        UIImage *metricPic = [UIImage imageNamed:@"temperatureMonoFinal.png"];
        [self.metricIconImageView setImage:metricPic];
        self.topTextField.hidden = NO;
        self.bottomTextField.hidden = NO;
        
        // if Speed is selected
    }else if(self.unitTypeButton.selectedSegmentIndex == 1){
        
        // display images and labels related to speed
        [self.unitMeasureTopLabel setText:@"mile"];
        [self.unitMeasureBottomLabel setText:@"km"];
        [self.metricLabel setText:@"Speed"];
        [self.topTextField setPlaceholder:@"Miles"];
        [self.bottomTextField setPlaceholder:@"Kilometers"];
        UIImage *metricPic = [UIImage imageNamed:@"speedFinal.png"];
        [self.metricIconImageView setImage:metricPic];
        self.topTextField.hidden = NO;
        self.bottomTextField.hidden = NO;
        
        // if Weight is selected
    }else if(self.unitTypeButton.selectedSegmentIndex == 2){
        
        // display images and labels related to weight
        [self.unitMeasureTopLabel setText:@"lb"];
        [self.unitMeasureBottomLabel setText:@"kg"];
        [self.metricLabel setText:@"Weight"];
        [self.topTextField setPlaceholder:@"Pounds"];
        [self.bottomTextField setPlaceholder:@"Kilograms"];
        UIImage *metricPic = [UIImage imageNamed:@"weightFinal.png"];
        [self.metricIconImageView setImage:metricPic];
        self.topTextField.hidden = NO;
        self.bottomTextField.hidden = NO;
        
        // if Fluid is selected
    }else if(self.unitTypeButton.selectedSegmentIndex == 3){
        
        // display images and labels related to fluid
        [self.unitMeasureTopLabel setText:@"US gal"];
        [self.unitMeasureBottomLabel setText:@"l"];
        [self.metricLabel setText:@"Fluid"];
        [self.topTextField setPlaceholder:@"Gallons"];
        [self.bottomTextField setPlaceholder:@"Liters"];
        UIImage *metricPic = [UIImage imageNamed:@"fluidFinal.png"];
        [self.metricIconImageView setImage:metricPic];
        self.topTextField.hidden = NO;
        self.bottomTextField.hidden = NO;
    }
}

// method that clears the screen
-(IBAction)clearScreen:(id)sender{
    self.topTextField.hidden = YES;
    self.bottomTextField.hidden = YES;
    self.metricIconImageView.hidden = NO;
    [self.topTextField setText:nil];
    [self.bottomTextField setText:nil];
   }

// retract keypad when background is tapped
-(IBAction)backgroundTap:(id)sender{
    [self.topTextField resignFirstResponder];
    [self.bottomTextField resignFirstResponder];
    [self.topTextField setText:nil];
    [self.bottomTextField setText:nil];
}

// erases the textfields when active
- (IBAction)eraseTextFields:(id)sender {
    [self.topTextField setText:nil];
    [self.bottomTextField setText:nil];
}

@end
